<a href="/">
    <img src="<?php echo e(asset('/assets/logo.svg')); ?>" alt="Logo" width="100px">
</a>
<?php /**PATH E:\OpenServer\domains\entertainment\resources\views/components/application-logo.blade.php ENDPATH**/ ?>