require('./bootstrap');
require('./admin');
require('./datatable');
require('./cart');
require('./dashboard');
require('./payment');
require('./reservation');
require('./phone-mask');
require('./zoom');


import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
