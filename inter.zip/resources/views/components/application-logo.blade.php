<a href="/">
    <img src="{{ asset('/assets/logo.svg') }}" alt="Logo" width="100px">
</a>
